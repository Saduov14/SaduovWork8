from PyQt6.QtWidgets import QMainWindow, QTabWidget
from gui.quest_wizard import QuestWizard
from gui.map_editor import MapEditor
from gui.gamification_panel import GamificationPanel
from core.database import create_tables

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Квест-Мастер")

        create_tables()

        self.tabs = QTabWidget()
        self.tabs.addTab(QuestWizard(), "Quest Wizard")
        self.tabs.addTab(MapEditor(), "Map Editor")
        self.tabs.addTab(GamificationPanel(), "Gamification")

        self.setCentralWidget(self.tabs)
