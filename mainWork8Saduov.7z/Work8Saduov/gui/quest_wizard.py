from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QTextEdit, QComboBox, QSpinBox, QDateTimeEdit, QPushButton, QMessageBox
from PyQt6.QtGui import QIntValidator
from core.database import get_connection
from datetime import datetime

class QuestWizard(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout()

        self.title_edit = QLineEdit()
        self.title_edit.setMaxLength(50)
        self.layout.addWidget(QLabel("Название квеста"))
        self.layout.addWidget(self.title_edit)

        self.difficulty_combo = QComboBox()
        self.difficulty_combo.addItems(["Легкий", "Средний", "Сложный", "Эпический"])
        self.layout.addWidget(QLabel("Сложность"))
        self.layout.addWidget(self.difficulty_combo)

        self.reward_spin = QSpinBox()
        self.reward_spin.setRange(10, 10000)
        self.layout.addWidget(QLabel("Награда"))
        self.layout.addWidget(self.reward_spin)

        self.description_edit = QTextEdit()
        self.layout.addWidget(QLabel("Описание"))
        self.layout.addWidget(self.description_edit)

        self.deadline_edit = QDateTimeEdit()
        self.deadline_edit.setDateTime(datetime.now())
        self.layout.addWidget(QLabel("Дедлайн"))
        self.layout.addWidget(self.deadline_edit)

        self.create_btn = QPushButton("Создать квест")
        self.create_btn.clicked.connect(self.create_quest)
        self.layout.addWidget(self.create_btn)

        self.setLayout(self.layout)

    def create_quest(self):
        title = self.title_edit.text().strip()
        difficulty = self.difficulty_combo.currentText()
        reward = self.reward_spin.value()
        description = self.description_edit.toPlainText().strip()
        deadline = self.deadline_edit.dateTime().toString()

        if not title or len(description.split()) < 5:
            QMessageBox.warning(self, "Ошибка", "Введите название и описание (мин. 5 слов)")
            return

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO quests (title, difficulty, reward, description, deadline)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, difficulty, reward, description, deadline))
        conn.commit()
        conn.close()

        QMessageBox.information(self, "Успех", "Квест создан!")

