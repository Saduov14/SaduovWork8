from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar

class GamificationPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.xp = 0
        self.level = "Ученик"

        layout = QVBoxLayout()
        self.label = QLabel(f"Уровень: {self.level}")
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(self.xp)

        layout.addWidget(self.label)
        layout.addWidget(self.progress)
        self.setLayout(layout)
