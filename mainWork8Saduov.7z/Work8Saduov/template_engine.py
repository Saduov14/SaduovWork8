from jinja2 import Environment, FileSystemLoader
import weasyprint
from docx import Document
import os
from datetime import datetime

TEMPLATES_DIR = "templates"
EXPORT_DIR = "./parchments"

class TemplateEngine:
    def __init__(self):
        self.env = Environment(loader=FileSystemLoader(TEMPLATES_DIR))
        os.makedirs(EXPORT_DIR, exist_ok=True)

    def render_template(self, template_name, quest):
        template = self.env.get_template(template_name)
        return template.render(quest=quest, date=datetime.now().strftime("%Y-%m-%d"))

    def export_pdf(self, template_name, quest, filename=None):
        html_content = self.render_template(template_name, quest)
        if not filename:
            filename = os.path.join(EXPORT_DIR, f"{quest['id']}_{int(datetime.now().timestamp())}.pdf")
        weasyprint.HTML(string=html_content).write_pdf(filename)
        return filename

    def export_docx(self, template_name, quest, filename=None):
        html_content = self.render_template(template_name, quest)
        if not filename:
            filename = os.path.join(EXPORT_DIR, f"{quest['id']}_{int(datetime.now().timestamp())}.docx")
        doc = Document()
        doc.add_paragraph(html_content)
        doc.save(filename)
        return filename
