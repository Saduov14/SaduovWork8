class Gamification:
    LEVELS = {
        "Ученик": 0,
        "Мастер пергаментов": 50,
        "Архимаг документов": 100
    }

    def __init__(self):
        self.xp = 0
        self.level = "Ученик"

    def add_xp(self, points):
        self.xp += points
        self.update_level()

    def update_level(self):
        if self.xp >= self.LEVELS["Архимаг документов"]:
            self.level = "Архимаг документов"
        elif self.xp >= self.LEVELS["Мастер пергаментов"]:
            self.level = "Мастер пергаментов"
        else:
            self.level = "Ученик"
