from PyQt6.QtWidgets import QMainWindow, QStackedWidget, QWidget, QVBoxLayout
from gui.quest_wizard import QuestWizard
from gui.map_editor import MapEditor
from gui.gamification_panel import GamificationPanel

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Генератор приключений")
        self.setGeometry(100, 100, 1000, 800)

        self.stacked_widget = QStackedWidget(self)
        self.setCentralWidget(self.stacked_widget)

        # Добавляем панели
        self.quest_wizard = QuestWizard()
        self.map_editor = MapEditor()
        self.gamification_panel = GamificationPanel()

        self.stacked_widget.addWidget(self.quest_wizard)
        self.stacked_widget.addWidget(self.map_editor)
        self.stacked_widget.addWidget(self.gamification_panel)
