from PyQt6.QtWidgets import QWidget, QLineEdit, QComboBox, QSpinBox, QTextEdit, QDateTimeEdit, QPushButton, QVBoxLayout, QMessageBox
from PyQt6.QtCore import Qt
import sqlite3

class QuestWizard(QWidget):
    def __init__(self):
        super().__init__()

        # Поля ввода
        self.title_input = QLineEdit(self)
        self.title_input.setPlaceholderText("Название квеста")
        
        self.difficulty_input = QComboBox(self)
        self.difficulty_input.addItems(["Легкий", "Средний", "Сложный", "Эпический"])
        
        self.reward_input = QSpinBox(self)
        self.reward_input.setRange(10, 10000)
        
        self.description_input = QTextEdit(self)
        self.description_input.setPlaceholderText("Описание квеста")
        
        self.deadline_input = QDateTimeEdit(self)
        
        # Кнопка для создания
        self.create_button = QPushButton("Создать квест", self)
        self.create_button.clicked.connect(self.create_quest)

        # Layout
        layout = QVBoxLayout(self)
        layout.addWidget(self.title_input)
        layout.addWidget(self.difficulty_input)
        layout.addWidget(self.reward_input)
        layout.addWidget(self.description_input)
        layout.addWidget(self.deadline_input)
        layout.addWidget(self.create_button)

    def create_quest(self):
        title = self.title_input.text()
        difficulty = self.difficulty_input.currentText()
        reward = self.reward_input.value()
        description = self.description_input.toPlainText()
        deadline = self.deadline_input.dateTime().toString()

        if not title or len(description.split()) < 50:
            QMessageBox.warning(self, "Ошибка", "Название и описание квеста обязательны!")
            return

        # Сохраняем в БД
        conn = sqlite3.connect('quests.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO quests (title, difficulty, reward, description, deadline)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, difficulty, reward, description, deadline))
        conn.commit()
        conn.close()

        QMessageBox.information(self, "Успех", "Квест создан успешно!")
