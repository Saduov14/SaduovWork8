from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar

class GamificationPanel(QWidget):
    def __init__(self):
        super().__init__()

        self.xp = 0
        self.level = "Ученик"

        layout = QVBoxLayout()

        self.label = QLabel(f"Уровень: {self.level}")
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(self.xp)

        layout.addWidget(self.label)
        layout.addWidget(self.progress)

        self.setLayout(layout)

    def add_xp(self, points: int):
        self.xp += points
        if self.xp > 100:
            self.xp = 100

        self.progress.setValue(self.xp)

        # простая логика уровней
        if self.xp < 50:
            self.level = "Ученик"
        elif self.xp < 100:
            self.level = "Мастер пергаментов"
        else:
            self.level = "Архимаг документов"

        self.label.setText(f"Уровень: {self.level}")
