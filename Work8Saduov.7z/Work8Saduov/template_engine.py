from jinja2 import Template
import weasyprint
from docx import Document

class TemplateEngine:
    @staticmethod
    def render_template(template_name, context):
        with open(f"templates/{template_name}", "r") as file:
            template = Template(file.read())
        return template.render(context)

    @staticmethod
    def export_pdf(html_content, filename):
        weasyprint.HTML(string=html_content).write_pdf(filename)

    @staticmethod
    def export_docx(context, filename):
        doc = Document()
        doc.add_heading(f"Квест {context['quest']['title']}", 0)
        doc.add_paragraph(f"Сложность: {context['quest']['difficulty']}")
        doc.add_paragraph(f"Вознаграждение: {context['quest']['reward']} золотых")
        doc.add_paragraph(f"Описание: {context['quest']['description']}")
        doc.save(filename)
