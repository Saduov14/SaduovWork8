import sqlite3

def create_tables():
    conn = sqlite3.connect('quests.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS quests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT UNIQUE NOT NULL,
            difficulty TEXT CHECK(difficulty IN ('Легкий','Средний','Сложный','Эпический')),
            reward INTEGER,
            description TEXT,
            deadline TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS quest_versions (
            id INTEGER PRIMARY KEY,
            quest_id INTEGER,
            title TEXT,
            difficulty TEXT,
            reward INTEGER,
            description TEXT,
            created_at TIMESTAMP,
            FOREIGN KEY (quest_id) REFERENCES quests(id)
        )
    ''')
    conn.commit()
    conn.close()

create_tables()
